import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(title: Text('Rêbaz')),
      body: Center(child: Text('Welcome to Rêbaz')),
    ),
  ));
}
